### Hexlet tests and linter status:
[![Actions Status](https://github.com/SovaDekster/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SovaDekster/python-project-49/actions)
#codeclimate: 
<a href="https://codeclimate.com/github/SovaDekster/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/9dbbc60eae0a9b25baf4/maintainability" /></a>

The is a project, which consists of 5 games.
You can clone the repository with git@github.com:SovaDekster/python-project-49.git

Also you can use some helpful commands:

make install

make build

make publish

make package-install

To start every game you can enter:

brain-even - first game

brain-calc - second game

brain-gcd - third game

brain-progression - fourth game

brain-prime - fifth game

If you want to view video for the first game:
https://asciinema.org/a/uavicakSHatg4xBY7QLT3dZb0

If you want to view video for the second game:
https://asciinema.org/a/MPuZFEAwHPo1d3zaLT5d3VmP0

If you want to view video for the third game:
https://asciinema.org/a/ixY5kx26OIdiw2xhsLoQhbGDZ

If you want to view video for the fourth game:
https://asciinema.org/a/QPwJtbZY9W6iMSSPRqvXJZGJc
