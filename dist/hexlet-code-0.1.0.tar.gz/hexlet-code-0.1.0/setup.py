# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'for project',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/SovaDekster/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SovaDekster/python-project-49/actions)\n#codeclimate: \n<a href="https://codeclimate.com/github/SovaDekster/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/9dbbc60eae0a9b25baf4/maintainability" /></a>\n\nThe is a project, which consists of 5 games.\nYou can clone the repository with git@github.com:SovaDekster/python-project-49.git\n\nAlso you can use some helpful commands:\n\nmake install\n\nmake build\n\nmake publish\n\nmake package-install\n\nTo start every game you can enter:\n\nbrain-even - first game\n\nbrain-calc - second game\n\nIf you want to view video for the first game:\nhttps://asciinema.org/a/uavicakSHatg4xBY7QLT3dZb0\n\nIf you want to view video for the second game:\nhttps://asciinema.org/a/MPuZFEAwHPo1d3zaLT5d3VmP0\n',
    'author': 'Евгения Ольшанова',
    'author_email': 'olshanova1995@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/SovaDekster/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
